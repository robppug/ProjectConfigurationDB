from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database Configuration
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(basedir, 'project_configurations.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class ProjectConfiguration(db.Model):
    __tablename__ = 'project_configurations'
    id = db.Column(db.Integer, primary_key=True)
    project = db.Column(db.String(100), nullable=False)
    project_stage = db.Column(db.String(50))
    last_updated = db.Column(db.String(50))

    # Cognitive Features
    cog_del_inattentive = db.Column("COG-DEL-INATTENTIVE", db.String(10))
    cog_del_disengaged = db.Column("COG-DEL-DISENGAGED", db.String(10))
    cog_del_distracted = db.Column("COG-DEL-DISTRACTED", db.String(10))
    cog_dil_drowsy = db.Column("COG-DIL-DROWSY", db.String(10))
    cog_dil_microsleeping = db.Column("COG-DIL-MICROSLEEPING", db.String(10))
    cog_dil_sleeping = db.Column("COG-DIL-SLEEPING", db.String(10))

    # Visual Recognition Features
    vis_gesture_head = db.Column("VIS-GESTURE-HEAD", db.String(10))
    vis_activity_ahp = db.Column("VIS-ACTIVITY-AHP", db.String(10))
    vis_activity_handpos = db.Column("VIS-ACTIVITY-HANDPOS", db.String(10))
    vis_activity_helditem = db.Column("VIS-ACTIVITY-HELDITEM", db.String(10))
    vis_activity_oop = db.Column("VIS-ACTIVITY-OOP", db.String(10))
    vis_mouth_speak = db.Column("VIS-MOUTH-SPEAK", db.String(10))
    vis_mouth_laugh = db.Column("VIS-MOUTH-LAUGH", db.String(10))
    vis_mouth_cough = db.Column("VIS-MOUTH-COUGH", db.String(10))
    vis_mouth_sneeze = db.Column("VIS-MOUTH-SNEEZE", db.String(10))
    vis_mouth_yawn = db.Column("VIS-MOUTH-YAWN", db.String(10))
    vis_smoke = db.Column("VIS-SMOKE", db.String(10))
    vis_phone = db.Column("VIS-PHONE", db.String(10))
    vis_das_coarse = db.Column("VIS-DAS-COARSE", db.String(10))
    vis_das_fine = db.Column("VIS-DAS-FINE", db.String(10))
    vis_das_ray = db.Column("VIS-DAS-RAY", db.String(10))
    
    # Standard Compliance Fields
    aspice_level = db.Column(db.Text)
    aspice_version = db.Column(db.Text)
    iso26262_level = db.Column(db.Text)
    iso26262_version = db.Column(db.Text)
    iso21448 = db.Column( db.Text)
    iso21434 = db.Column(db.Text)
    
    # Hardware/Platform Fields
    ti_sitara = db.Column(db.Text)
    amd_zynq = db.Column(db.Text)
    renesas_v4h = db.Column(db.Text)
    
    def __repr__(self):
        return f"<Project {self.project}>"

# Home route: List all configurations using the ORM.
@app.route('/')
def index():
    projects = ProjectConfiguration.query.all()
    project_stages = sorted(set(project.project_stage for project in projects if project.project_stage))  # Get unique stages
    return render_template('index.html', projects=projects, project_stages=project_stages)

def populate_project_from_form(project):
    """ Helper function to populate project attributes from form """
    form_fields = [
        "project",
        "project_stage",
        "last_updated",
        "COG-DEL-INATTENTIVE",
        "COG-DEL-DISENGAGED", 
        "COG-DEL-DISTRACTED",
        "COG-DIL-DROWSY", 
        "COG-DIL-MICROSLEEPING", 
        "COG-DIL-SLEEPING",
        "VIS-GESTURE-HEAD", 
        "VIS-ACTIVITY-AHP", 
        "VIS-ACTIVITY-HANDPOS",
        "VIS-ACTIVITY-HELDITEM", 
        "VIS-ACTIVITY-OOP",
        "VIS-MOUTH-SPEAK",
        "VIS-MOUTH-LAUGH",
        "VIS-MOUTH-COUGH",
        "VIS-MOUTH-SNEEZE",
        "VIS-MOUTH-YAWN",
        "VIS-SMOKE",
        "VIS-PHONE",
        "VIS-DAS-COARSE",
        "VIS-DAS-FINE",
        "VIS-DAS-RAY",
        "aspice_level", 
        "aspice_version", 
        "iso26262_level",
        "iso26262_version", 
        "iso21448", 
        "iso21434",
        "ti_sitara", 
        "amd_zynq", 
        "renesas_v4h"
    ]
    
    for field in form_fields:
        setattr(project, field, request.form.get(field))

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        try:
            new_project = ProjectConfiguration()
            populate_project_from_form(new_project)

            db.session.add(new_project)
            db.session.commit()
            flash('Project added successfully.', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding project: {str(e)}', 'error')

    return render_template('add.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    project = ProjectConfiguration.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            populate_project_from_form(project)
            project.last_updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Update timestamp
            db.session.commit()
            flash('Project updated successfully.', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating project: {str(e)}', 'error')

    return

@app.route('/settings')
def settings():
    return render_template('settings.html')

@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    project = ProjectConfiguration.query.get_or_404(id)
    
    try:
        db.session.delete(project)
        db.session.commit()
        flash('Project deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting project: {str(e)}', 'error')

    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=80, use_reloader=False)
